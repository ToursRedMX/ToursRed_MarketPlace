# approve-agency-documents — fix completo del bloque PDF (para Bolt)

## Qué está roto y ya arreglé en Supabase (v46, ya en producción)

`approve-agency-documents` estaba en 2 partes:
1. **AAL2 real en las 3 acciones (approve/reject/resign)** — ✅ corregido y desplegado.
2. **Bug de imports faltantes en el flujo `resign`** (enmienda de comisión) — el código
   usaba `PdfPrinter`, `buildContractDocDefinition`, `getFonts()`, sin ningún `import`.
   Si alguien intentaba cambiar la comisión de una agencia activa, esto truena en
   tiempo de ejecución.

**No pude desplegar el fix del PDF yo mismo** porque depende de dos archivos
compartidos (`_shared/robotoFonts.ts` y `_shared/contractDocDefinition.ts`) que pesan
~950KB combinados en base64 — pegarlos a mano por este chat arriesgaba corromper
los datos de las fuentes. Por eso la versión que subí a Supabase (v46) tiene el
fix de AAL2 real, pero el bloque de generación de PDF quedó **exactamente igual
que antes** (roto, pero no peor de lo que ya estaba).

## Archivo incluido

`supabase/functions/approve-agency-documents/index.ts` — versión completa con
AAL2 **y** el fix del PDF, usando el mismo patrón de imports dinámicos perezosos
que ya usa `verify-contract-otp` (que sí funciona en producción):

```ts
const { default: PdfPrinter } = await import("npm:pdfmake@0.2.20");
const { Buffer } = await import("node:buffer");
const {
  ROBOTO_NORMAL_B64, ROBOTO_BOLD_B64, ROBOTO_ITALICS_B64, ROBOTO_BOLDITALICS_B64,
} = await import("../_shared/robotoFonts.ts");
const { buildContractDocDefinition } = await import("../_shared/contractDocDefinition.ts");
```

## Cómo aplicarlo

1. Copia el archivo sobre `supabase/functions/approve-agency-documents/index.ts`
   en tu copia local del repo (Bolt ya tiene `_shared/robotoFonts.ts` y
   `_shared/contractDocDefinition.ts` reales, no hace falta tocarlos).
2. Antes de desplegar, verifica con `get_edge_function` que la versión actual en
   Supabase sigue siendo la v46 que dejé (para no pisar nada nuevo).
3. Deploy normal vía Bolt.
4. Prueba manual recomendada: intenta iniciar una enmienda de comisión (`resign`)
   para una agencia activa y confirma que el PDF se genera sin error 500.
