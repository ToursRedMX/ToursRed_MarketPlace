# Correcciones de Fase 2/3 (MFA + Step-up) — listas para aplicar

Verificadas contra el repo real (`ToursRedMX/ToursRed_MarketPlace`, commit `fc5b11e`) y
con `npx vite build` exitoso — el mismo comando que usa Netlify para producción.

## Archivos incluidos (6)

```
src/context/StepUpContext.tsx          ← NUEVO
src/main.tsx                           ← modificado
src/components/MfaSettingsSection.tsx  ← modificado
src/components/MfaGate.tsx             ← modificado
src/pages/traveler/TravelerBookings.tsx ← modificado
src/pages/traveler/TravelerProfile.tsx  ← modificado
```

## Qué corrige cada uno

- **StepUpContext.tsx (nuevo):** el componente "StepUpGate" que faltaba. Intercepta
  cualquier respuesta 403 con `code: MFA_NOT_CONFIGURED` o `code: STEP_UP_REQUIRED`
  de las funciones de pago con wallet/puntos, muestra el modal correspondiente
  ("Protege tus fondos" o pedir TOTP), y reintenta el pago automáticamente si el
  usuario se verifica.
- **main.tsx:** conecta `StepUpProvider` globalmente (dentro del Router, porque usa
  `useNavigate`).
- **TravelerBookings.tsx:** los 3 puntos donde se paga un suplemento o un extra con
  ToursRed Cash/puntos ahora usan `fetchWithStepUp` en vez de `fetch` normal.
- **TravelerProfile.tsx:** agrega `<MfaSettingsSection />` — antes los viajeros no
  tenían NINGUNA forma de activar MFA desde su perfil (solo existía en el perfil de
  admin).
- **MfaSettingsSection.tsx:** reescrito. Corrige el doble `challenge()` (llamaba a
  `supabase.auth.mfa.challenge()` dos veces seguidas, desperdiciando una llamada).
  Agrega toda la UI de recovery codes: generación automática al activar MFA, modal
  para copiar/descargar los 10 códigos, contador "Códigos restantes: X de 10", y
  botón de regenerar con confirmación TOTP.
- **MfaGate.tsx:** mismo fix del doble `challenge()`, en el flujo de login de admin.

## Cómo aplicarlos

1. Copia estos 6 archivos sobre tu copia local del repo, respetando las rutas
   exactas (mismo `src/...`).
2. Revisa el diff si quieres confirmar antes de subir:
   ```
   git status
   git diff
   ```
3. Commit y push normal:
   ```
   git add src/context/StepUpContext.tsx src/main.tsx src/components/MfaSettingsSection.tsx src/components/MfaGate.tsx src/pages/traveler/TravelerBookings.tsx src/pages/traveler/TravelerProfile.tsx
   git commit -m "MFA: recovery codes UI, step-up gate, fix doble challenge"
   git push
   ```
4. Netlify va a desplegar automáticamente desde `main` (confirmado en `netlify.toml`).

## Importante: backend ya está desplegado y en producción

El backend (Edge Functions `generate-recovery-codes`, `use-recovery-code`,
`invalidate-recovery-codes`, `verify-sensitive-action`, y el step-up real en
`process-supplement-payment`/`purchase-post-booking-extras`) ya fue corregido y
desplegado directamente en Supabase por Claude durante esta sesión — **no está en
git todavía**. Antes de que Bolt vuelva a tocar cualquiera de esas Edge Functions,
debe leer el código real desplegado con `get_edge_function`, no asumir que su copia
local sigue vigente.

## Pendiente conocido (no bloqueante, pero anótalo)

Hay un ~25-30 funciones administrativas de la Fase 1 (AAL2) que quedaron pendientes
de auditoría completa. Y no se verificó todavía el "banner de MFA" en los
dashboards (Bolt reportó haberlo hecho, pero dado el patrón de hoy, vale la pena
confirmarlo con el mismo método: leer el código real, no el reporte).
